#!/bin/sh
set -eu
cd "$(dirname "$0")"
mkdir -p bin
"${CC:-cc}" -std=c11 -O2 -Wall -Wextra -Wpedantic -Werror \
  src/main.c src/io.c src/sort.c src/benchmark.c -o bin/aps
./bin/aps selftest
