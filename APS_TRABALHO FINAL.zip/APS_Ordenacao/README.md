# APS de Ciência da Computação

Sistema para análise de desempenho de algoritmos de ordenação, implementado em C11.
O cenário da Amazônia é uma simulação: os números representam códigos de imagens;
o programa não baixa, processa nem classifica imagens reais de satélite.

## Começar no Windows

Extraia todo o ZIP antes de executar. O executável pronto é `bin/aps.exe`, para Windows x64.
Abra PowerShell na pasta do projeto e execute:

```powershell
.\bin\aps.exe selftest
.\bin\aps.exe demo dados/demo.txt 12
.\bin\aps.exe suite dados 5 resultados/nova_execucao.csv
```

Alternativa: `powershell -ExecutionPolicy Bypass -File .\apresentar.ps1`.
O script executa os testes, a demonstração e os cinco tamanhos. Cada apresentação
cria outro CSV com data e hora. A demonstração das etapas não entra na medição.

## Compilar

Não há dependências externas no programa C. Use um compilador com suporte a C11
e inteiros de 32 e 64 bits. O executável entregue foi compilado com Zig 0.15.2
(`zig cc`, frontend Clang) e `-std=c11 -O2 -Wall -Wextra -Wpedantic -Werror`.
Zig é apenas a ferramenta de compilação; todo o sistema está escrito em C.

```powershell
.\build.ps1                         # GCC disponível no PATH
.\build.ps1 -Compiler clang
.\build.ps1 -Compiler C:\caminho\zig.exe
```

Linux/macOS: `sh build.sh`, seguido de `./bin/aps selftest`.
Esses sistemas exigem recompilação; o binário Windows não foi testado neles.

## Comandos

```text
aps generate ARQUIVO N SEMENTE PERFIL
aps generate-suite DIRETORIO
aps benchmark ARQUIVO N REPETICOES SAIDA.csv
aps suite DIRETORIO REPETICOES SAIDA.csv
aps demo ARQUIVO N
aps selftest
```

Os diretórios devem existir. Os arquivos de saída devem ser novos: o modo `wx`
recusa sobrescritas. Se ocorrer falha, um CSV parcial pode permanecer; use outro
nome para repetir. O intervalo aceito é de 1 a 5.000.000 registros e de 1 a 100
repetições. `demo` aceita no máximo 32 registros. Semente: 1 a 4.294.967.295.
Perfis: `random`, `sorted`, `reverse`, `duplicates`.

Os arquivos de entrada contêm inteiros decimais sem sinal, separados por espaços,
tabulações ou quebras de linha. O leitor aceita de 0 a 4.294.967.295, verifica a
quantidade exata e recusa caracteres inválidos e estouro numérico. O gerador
produz códigos entre 100.000 e 999.999; repetição de códigos é permitida.

Exemplo de novo experimento:

```powershell
New-Item -ItemType Directory -Force dados_novos | Out-Null
.\bin\aps.exe generate-suite dados_novos
.\bin\aps.exe suite dados_novos 5 resultados/outro_computador.csv
.\bin\aps.exe generate dados_novos/reverso.txt 50000 202602 reverse
.\bin\aps.exe benchmark dados_novos/reverso.txt 50000 5 resultados/reverso.csv
```

## Como as medições funcionam

1. Carrega e valida o arquivo externo uma vez.
2. Prepara uma referência com `qsort` fora da medição.
3. Reserva memória e aquece cada algoritmo, também fora da medição.
4. Prepara cópias idênticas dos dados antes de cada medição.
5. Cronometra somente as chamadas de ordenação, sem leitura, cópia de entrada,
   validação, alocação, exportação de CSV ou mensagens de tela.
6. Confere todos os resultados, elemento a elemento, com a referência.

Os algoritmos comparados são implementações próprias de Quick Sort com pivô
mediana de três e partição em três vias, Merge Sort estável com buffer reutilizado
e Heap Sort iterativo. `qsort` não é um quarto concorrente e seu algoritmo interno
não é presumido.

Para N <= 50.000, cada medição ordena `floor(1.000.000/N)` vetores independentes
preparados antes do relógio; para N maior, o lote tem um vetor. O CSV contém o
tempo total do lote e o tempo médio por ordenação. O laço e a chamada de função
fazem parte do pequeno custo do trecho cronometrado. A cópia interna do Merge
Sort integra o algoritmo e fica dentro da medição. A reserva de seu buffer fica
fora e seu custo de memória é discutido separadamente.

O relógio é `clock()` de `<time.h>`, convertido por `CLOCKS_PER_SEC`. Pela norma C,
esse relógio representa tempo de processador; no CRT Windows usado aqui ele
mede tempo decorrido. Não misture medições de plataformas sem documentar essa
diferença. `CLOCKS_PER_SEC` é a escala, não garantia de resolução efetiva.
Os tempos pequenos são estimativas por lote, e casas decimais não indicam
precisão física. A ordem dos algoritmos gira a cada repetição. A mediana de
cinco médias de lote resume o experimento, sem inferência estatística universal.

## Estrutura da entrega

- `src/`: todo o código C e cabeçalho.
- `bin/aps.exe`: programa Windows x64 pronto para executar.
- `dados/`: cinco arquivos obrigatórios, demonstração e perfis adicionais.
- `resultados/`: tempos brutos, resumo, ambiente, integridade e registros dos testes.
- `docs/Briefing_e_plano.pdf`: escopo, decisões e critérios de aceite.
- `docs/Relatorio_APS.pdf`: texto acadêmico, resultados, referências e código numerado.
- `docs/Relatorio_APS_editavel.html`: fonte textual editável, inclusive no Word.
- `docs/Ficha_APS_modelo_oficial.pdf`: última página do enunciado, intacta.
- `docs/Roteiro_apresentacao.txt`: sequência de exposição e perguntas para estudo.
- `tests/test_cli.py`: testes opcionais de entrada e contrato; requer Python 3.

O relatório usa A4, Arial 12, margens superior/esquerda de 3 cm e demais de 2 cm,
texto com entrelinha de 1,5, paginação a partir da introdução e fontes das figuras.
O código do apêndice usa fonte monoespaçada menor para preservar a legibilidade.

## Personalização antes da entrega acadêmica

Preencha nomes, RAs, campus, professor, cidade e confirme o período com o docente.
A capa do enunciado menciona 2025/2; o nome do arquivo menciona 2026/2. A hipótese
de trabalho foi 2026/2. O prazo e a data da apresentação dependem do calendário
e do professor e não foram presumidos. Duplique a ficha oficial para cada
integrante (grupo de 3 a 5, salvo autorização da coordenação), registre apenas
atividades e horas efetivamente realizadas e obtenha as assinaturas exigidas.

O grupo precisa estudar, revisar e validar o conteúdo, registrar suas próprias
contribuições e experiências formativas e observar a orientação institucional
sobre autoria e uso de IA. Nenhuma participação, hora ou assinatura foi inventada.
A entrega no portal acadêmico não foi realizada.
