$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    & ./bin/aps.exe selftest
    if ($LASTEXITCODE -ne 0) { throw "Selftest falhou." }
    & ./bin/aps.exe demo dados/demo.txt 12
    if ($LASTEXITCODE -ne 0) { throw "Demonstracao falhou." }
    $stamp = Get-Date -Format "yyyyMMdd_HHmmss_fff"
    & ./bin/aps.exe suite dados 5 "resultados/apresentacao_$stamp.csv"
    if ($LASTEXITCODE -ne 0) { throw "Benchmark falhou." }
    Write-Host "Concluido. O CSV foi salvo em resultados."
} finally { Pop-Location }
