"""Testes externos de contrato; Python e necessario apenas para estes testes."""
import pathlib
import subprocess
import tempfile
import sys

root = pathlib.Path(__file__).resolve().parents[1]
exe = root / 'bin' / ('aps.exe' if sys.platform == 'win32' else 'aps')
checks = 0

def run(args, success):
    global checks
    p = subprocess.run([str(exe), *map(str, args)], capture_output=True, text=True)
    assert (p.returncode == 0) == success, (args, p.stdout, p.stderr)
    checks += 1
    return p

with tempfile.TemporaryDirectory(prefix='aps_tests_') as directory:
    d = pathlib.Path(directory)
    for i, data in enumerate(['', '1 2', '1 2 3 4', '1 -2 3',
                              '1 x 3', '1 4294967296 3', '1 2.5 3',
                              '1 2 3x', '1 +2 3']):
        f = d / f'bad_{i}.txt'
        f.write_text(data, encoding='ascii')
        run(['benchmark', f, 3, 1, d / f'bad_{i}.csv'], False)
    f = d / 'valid.txt'
    f.write_text('4294967295\t0\r\n2', encoding='ascii')
    p = run(['benchmark', f, 3, 2, d / 'valid.csv'], True)
    import csv
    rows = list(csv.DictReader((d / 'valid.csv').open()))
    assert len(rows) == 6 and all(r['validated'] == '1' for r in rows)
    original_bytes = f.read_bytes()
    run(['benchmark', f, 3, 1, f], False)
    assert f.read_bytes() == original_bytes
    run(['benchmark', d/'missing.txt', 3, 1, d/'missing.csv'], False)
    for n in ['0', '-1', '5000001', '99x', '99999999999999999999999']:
        run(['benchmark', f, n, 1, d / f'arg_{checks}.csv'], False)
    for reps in ['0', '-1', '101', 'x']:
        run(['benchmark', f, 3, reps, d / f'arg_{checks}.csv'], False)
    for profile in ['random', 'sorted', 'reverse', 'duplicates']:
        g = d / f'{profile}.txt'
        run(['generate', g, 100, 202602, profile], True)
        vals = list(map(int, g.read_text().split()))
        assert len(vals) == 100 and all(100000 <= x <= 999999 for x in vals)
        if profile == 'sorted': assert vals == sorted(vals)
        if profile == 'reverse': assert vals == sorted(vals, reverse=True)
        if profile == 'duplicates': assert len(set(vals)) <= 8
        run(['benchmark', g, 100, 1, d / f'{profile}.csv'], True)
    run(['generate', d/'badprofile.txt', 10, 1, 'unknown'], False)
    run(['generate', d/'badseed.txt', 10, 0, 'random'], False)
    run(['demo', f, 3], True)
    run(['demo', f, 33], False)
    run(['selftest'], True)
print(f'CLI: {checks} execucoes aprovadas; arquivos e CSV conferidos.')
