param([string]$Compiler = "gcc")
$ErrorActionPreference = "Stop"
Push-Location $PSScriptRoot
try {
    New-Item -ItemType Directory -Force bin | Out-Null
    $sources = @("src/main.c", "src/io.c", "src/sort.c", "src/benchmark.c")
    $flags = @("-std=c11", "-O2", "-Wall", "-Wextra", "-Wpedantic", "-Werror")
    if ([IO.Path]::GetFileNameWithoutExtension($Compiler) -eq "zig") {
        & $Compiler cc @flags @sources -o bin/aps.exe
    } else {
        & $Compiler @flags @sources -o bin/aps.exe
    }
    if ($LASTEXITCODE -ne 0) { throw "Falha na compilacao." }
    & ./bin/aps.exe selftest
    if ($LASTEXITCODE -ne 0) { throw "Falha nos testes." }
} finally { Pop-Location }
