#include "aps.h"
#include <string.h>

static void swap(uint32_t *a, uint32_t *b) {
    uint32_t v = *a; *a = *b; *b = v;
}

static void show(const char *stage, const uint32_t *a, size_t n) {
    size_t i;
    printf("  %-18s", stage);
    for (i = 0; i < n; ++i) printf(" %lu", (unsigned long)a[i]);
    putchar('\n');
}

static uint32_t median3(uint32_t a, uint32_t b, uint32_t c) {
    if (a > b) { uint32_t t = a; a = b; b = t; }
    if (b > c) b = c;
    return a > b ? a : b;
}

/* Intervalos semiabertos. Recursao apenas no menor lado limita a pilha. */
static void quick_range(uint32_t *a, size_t lo, size_t hi,
                        int trace, size_t total) {
    while (hi - lo > 1) {
        uint32_t pivot = median3(a[lo], a[lo + (hi-lo)/2], a[hi-1]);
        size_t lt = lo, i = lo, gt = hi;
        while (i < gt) {
            if (a[i] < pivot) { swap(&a[lt], &a[i]); ++lt; ++i; }
            else if (a[i] > pivot) { --gt; swap(&a[i], &a[gt]); }
            else ++i;
        }
        if (trace) show("particao em 3 vias", a, total);
        if (lt - lo < hi - gt) {
            quick_range(a, lo, lt, trace, total); lo = gt;
        } else {
            quick_range(a, gt, hi, trace, total); hi = lt;
        }
    }
}

void quick_sort(uint32_t *a, size_t n, uint32_t *tmp) {
    (void)tmp;
    quick_range(a, 0, n, 0, n);
}

static void merge_range(uint32_t *a, uint32_t *tmp, size_t lo,
                        size_t hi, int trace, size_t total) {
    size_t mid, i, j, k;
    if (hi - lo < 2) return;
    mid = lo + (hi-lo)/2;
    merge_range(a, tmp, lo, mid, trace, total);
    merge_range(a, tmp, mid, hi, trace, total);
    i = lo; j = mid; k = lo;
    while (i < mid && j < hi)
        tmp[k++] = a[i] <= a[j] ? a[i++] : a[j++];
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    memcpy(a + lo, tmp + lo, (hi-lo) * sizeof(*a));
    if (trace) show("intercalacao", a, total);
}

void merge_sort(uint32_t *a, size_t n, uint32_t *tmp) {
    merge_range(a, tmp, 0, n, 0, n);
}

static void sift_down(uint32_t *a, size_t root, size_t n) {
    while (root < n/2) {
        size_t child = root*2 + 1;
        if (child+1 < n && a[child] < a[child+1]) ++child;
        if (a[root] >= a[child]) break;
        swap(&a[root], &a[child]); root = child;
    }
}

static void heap_run(uint32_t *a, size_t n, int trace) {
    size_t i;
    for (i = n/2; i > 0; --i) sift_down(a, i-1, n);
    if (trace) show("heap construido", a, n);
    for (i = n; i > 1; --i) {
        swap(&a[0], &a[i-1]); sift_down(a, 0, i-1);
        if (trace) show("extracao do maior", a, n);
    }
}

void heap_sort(uint32_t *a, size_t n, uint32_t *tmp) {
    (void)tmp;
    heap_run(a, n, 0);
}

void trace_sort(uint32_t *a, size_t n, int algorithm) {
    uint32_t tmp[32];
    if (n > 32) return;
    show("entrada", a, n);
    if (algorithm == 0) quick_range(a, 0, n, 1, n);
    else if (algorithm == 1) merge_range(a, tmp, 0, n, 1, n);
    else heap_run(a, n, 1);
    show("saida", a, n);
}

int reference_compare(const void *va, const void *vb) {
    uint32_t a = *(const uint32_t *)va, b = *(const uint32_t *)vb;
    return (a > b) - (a < b);
}
