#include "aps.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>

static const SortFn functions[] = {quick_sort, merge_sort, heap_sort};
static const char *names[] = {"Quick Sort", "Merge Sort", "Heap Sort"};

int run_benchmark(const char *path, size_t n, size_t repetitions,
                  FILE *csv) {
    uint32_t *original = NULL, *reference = NULL, *work = NULL, *tmp = NULL;
    size_t batch = n <= 50000 ? 1000000/n : 1;
    size_t rep, order, b;
    int ok = 0;
    if (!load_data(path, n, &original)) goto done;
    reference = malloc(n*sizeof(*reference));
    work = malloc(n*batch*sizeof(*work));
    tmp = malloc(n*sizeof(*tmp));
    if (!reference || !work || !tmp) {
        fputs("Memoria insuficiente para benchmark.\n", stderr); goto done;
    }
    memcpy(reference, original, n*sizeof(*reference));
    qsort(reference, n, sizeof(*reference), reference_compare);
    /* Aquecimento nao contabilizado; qsort serve somente como oraculo. */
    for (order = 0; order < 3; ++order) {
        memcpy(work, original, n*sizeof(*work));
        functions[order](work, n, tmp);
        if (memcmp(work, reference, n*sizeof(*work))) goto done;
    }
    for (rep = 0; rep < repetitions; ++rep) {
        for (order = 0; order < 3; ++order) {
            size_t alg = (order + rep) % 3;
            clock_t start, end;
            double total;
            for (b = 0; b < batch; ++b)
                memcpy(work + b*n, original, n*sizeof(*work));
            printf("n=%lu repeticao=%lu %s: ordenando... ",
                   (unsigned long)n, (unsigned long)(rep+1), names[alg]);
            fflush(stdout);
            start = clock();
            for (b = 0; b < batch; ++b) functions[alg](work + b*n, n, tmp);
            end = clock();
            if (start == (clock_t)-1 || end == (clock_t)-1 || end < start) {
                fputs("Relogio indisponivel ou com overflow.\n", stderr);
                goto done;
            }
            total = (double)(end-start) / (double)CLOCKS_PER_SEC;
            for (b = 0; b < batch; ++b)
                if (memcmp(work + b*n, reference, n*sizeof(*work))) {
                    fputs("ERRO: resultado difere da referencia.\n", stderr);
                    goto done;
                }
            printf("%.9f s/ordenacao | validado | lote=%lu\n",
                   total/(double)batch, (unsigned long)batch);
            if (fprintf(csv, "%lu,%s,%lu,%lu,%.9f,%.12f,1,%ld\n",
                (unsigned long)n, names[alg], (unsigned long)(rep+1),
                (unsigned long)batch, total, total/(double)batch,
                (long)CLOCKS_PER_SEC) < 0) goto done;
            if (fflush(csv) != 0) goto done;
        }
    }
    ok = 1;
done:
    if (!ok) fputs("Benchmark interrompido; CSV pode estar parcial.\n", stderr);
    free(tmp); free(work); free(reference); free(original);
    return ok;
}

int selftest(void) {
    uint32_t a[513], ref[513], tmp[513], state = 202602u;
    size_t n, profile, alg, i, cases = 0;
    for (n = 0; n <= 513; ++n) {
        for (profile = 0; profile < 5; ++profile) {
            for (i = 0; i < n; ++i) {
                uint32_t value = profile == 0 ? rng_next(&state) :
                    profile == 1 ? (uint32_t)i :
                    profile == 2 ? (uint32_t)(n-i) :
                    profile == 3 ? 7u : (i%2 ? 0u : UINT32_MAX);
                ref[i] = value;
            }
            for (alg = 0; alg < 3; ++alg) {
                memcpy(a, ref, n*sizeof(*a));
                functions[alg](a, n, tmp);
                for (i = 1; i < n; ++i) if (a[i-1] > a[i]) return 0;
                /* Comparacao exata confere ordem e preservacao do multiconjunto. */
                {
                    uint32_t oracle[513];
                    memcpy(oracle, ref, n*sizeof(*oracle));
                    qsort(oracle, n, sizeof(*oracle), reference_compare);
                    if (memcmp(a, oracle, n*sizeof(*a))) return 0;
                }
                ++cases;
            }
        }
    }
    printf("Selftest: %lu casos aprovados.\n", (unsigned long)cases);
    return 1;
}
