#include "aps.h"
#include <stdlib.h>
#include <string.h>

static const size_t sizes[] = {500, 5000, 50000, 500000, 5000000};

static void usage(const char *name) {
    printf("APS - Analise de ordenacao em C11\n"
           "  %s selftest\n"
           "  %s generate ARQUIVO N SEMENTE PERFIL\n"
           "  %s generate-suite DIRETORIO\n"
           "  %s benchmark ARQUIVO N REPETICOES SAIDA.csv\n"
           "  %s suite DIRETORIO REPETICOES SAIDA.csv\n"
           "  %s demo ARQUIVO N (1 a 32)\n"
           "Perfis: random sorted reverse duplicates\n"
           "Arquivos de saida devem ser novos; limite: 5000000 registros.\n",
           name, name, name, name, name, name);
}

int main(int argc, char **argv) {
    size_t n, reps, seed, i;
    FILE *csv;
    int ok;
    if (argc == 2 && !strcmp(argv[1], "selftest"))
        return selftest() ? EXIT_SUCCESS : EXIT_FAILURE;
    if (argc == 6 && !strcmp(argv[1], "generate")) {
        if (!parse_size(argv[3], APS_MAX_N, &n) || !n ||
            !parse_size(argv[4], UINT32_MAX, &seed) || !seed) goto invalid;
        return generate_data(argv[2], n, (uint32_t)seed, argv[5]) ? 0 : 1;
    }
    if (argc == 3 && !strcmp(argv[1], "generate-suite")) {
        char path[1024];
        for (i = 0; i < 5; ++i) {
            int len = snprintf(path, sizeof(path), "%s/codigos_%lu.txt",
                               argv[2], (unsigned long)sizes[i]);
            if (len < 0 || (size_t)len >= sizeof(path)) goto invalid;
            if (!generate_data(path, sizes[i], 202602u, "random")) return 1;
            printf("Gerado: %s\n", path);
        }
        return 0;
    }
    if (argc == 4 && !strcmp(argv[1], "demo")) {
        uint32_t *original, work[32];
        const char *names[] = {"Quick Sort", "Merge Sort", "Heap Sort"};
        if (!parse_size(argv[3], 32, &n) || !n) goto invalid;
        if (!load_data(argv[2], n, &original)) return 1;
        puts("DEMONSTRACAO DE ETAPAS - sem medicao de desempenho");
        for (i = 0; i < 3; ++i) {
            puts(names[i]); memcpy(work, original, n*sizeof(*work));
            trace_sort(work, n, (int)i);
        }
        free(original); return 0;
    }
    if (argc == 6 && !strcmp(argv[1], "benchmark")) {
        if (!parse_size(argv[3], APS_MAX_N, &n) || !n ||
            !parse_size(argv[4], 100, &reps) || !reps) goto invalid;
        csv = fopen(argv[5], "wx");
        if (!csv) { perror(argv[5]); return 1; }
        if (fputs("n,algorithm,repetition,batch,total_seconds,seconds_per_sort,"
                  "validated,clock_ticks_per_second\n", csv) == EOF) {
            fclose(csv); return 1;
        }
        ok = run_benchmark(argv[2], n, reps, csv);
        if (fclose(csv) != 0) ok = 0;
        return ok ? 0 : 1;
    }
    if (argc == 5 && !strcmp(argv[1], "suite")) {
        char path[1024];
        if (!parse_size(argv[3], 100, &reps) || !reps) goto invalid;
        csv = fopen(argv[4], "wx");
        if (!csv) { perror(argv[4]); return 1; }
        ok = fputs("n,algorithm,repetition,batch,total_seconds,seconds_per_sort,"
                   "validated,clock_ticks_per_second\n", csv) != EOF;
        for (i = 0; i < 5 && ok; ++i) {
            int len = snprintf(path, sizeof(path), "%s/codigos_%lu.txt",
                               argv[2], (unsigned long)sizes[i]);
            ok = len >= 0 && (size_t)len < sizeof(path);
            if (ok) ok = run_benchmark(path, sizes[i], reps, csv);
        }
        if (fclose(csv) != 0) ok = 0;
        return ok ? 0 : 1;
    }
invalid:
    usage(argv[0]); return EXIT_FAILURE;
}
