#ifndef APS_H
#define APS_H
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>

#define APS_MAX_N ((size_t)5000000)
typedef void (*SortFn)(uint32_t *, size_t, uint32_t *);
void quick_sort(uint32_t *a, size_t n, uint32_t *tmp);
void merge_sort(uint32_t *a, size_t n, uint32_t *tmp);
void heap_sort(uint32_t *a, size_t n, uint32_t *tmp);
void trace_sort(uint32_t *a, size_t n, int algorithm);
int reference_compare(const void *a, const void *b);
uint32_t rng_next(uint32_t *state);
int parse_size(const char *s, size_t max, size_t *out);
int load_data(const char *path, size_t expected, uint32_t **out);
int generate_data(const char *path, size_t n, uint32_t seed,
                  const char *profile);
int run_benchmark(const char *path, size_t n, size_t repetitions,
                  FILE *csv);
int selftest(void);
#endif
