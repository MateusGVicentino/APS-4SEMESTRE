#include "aps.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

uint32_t rng_next(uint32_t *state) {
    uint32_t x = *state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    *state = x; return x;
}

int parse_size(const char *s, size_t max, size_t *out) {
    size_t v = 0;
    if (!s || !*s) return 0;
    for (; *s; ++s) {
        unsigned digit;
        if (*s < '0' || *s > '9') return 0;
        digit = (unsigned)(*s - '0');
        if (digit > max || v > (max-digit)/10) return 0;
        v = v*10 + digit;
    }
    *out = v; return 1;
}

int load_data(const char *path, size_t expected, uint32_t **out) {
    FILE *f;
    uint32_t *a;
    size_t count = 0;
    int c, ok = 1;
    *out = NULL;
    if (!expected || expected > APS_MAX_N) return 0;
    f = fopen(path, "rb");
    if (!f) { perror(path); return 0; }
    a = malloc(expected * sizeof(*a));
    if (!a) { fclose(f); fputs("Memoria insuficiente.\n", stderr); return 0; }
    while ((c = fgetc(f)) != EOF) {
        uint32_t value = 0;
        if (isspace((unsigned char)c)) continue;
        if (c < '0' || c > '9' || count == expected) { ok = 0; break; }
        do {
            uint32_t digit = (uint32_t)(c - '0');
            if (value > (UINT32_MAX-digit)/10) { ok = 0; break; }
            value = value*10 + digit;
            c = fgetc(f);
        } while (c >= '0' && c <= '9');
        if (!ok || (c != EOF && !isspace((unsigned char)c))) {
            ok = 0; break;
        }
        a[count++] = value;
    }
    if (ferror(f) || count != expected) ok = 0;
    if (fclose(f) != 0) ok = 0;
    if (!ok) {
        fprintf(stderr, "Arquivo invalido: %s (esperados %lu inteiros uint32).\n",
                path, (unsigned long)expected);
        free(a); return 0;
    }
    *out = a; return 1;
}

int generate_data(const char *path, size_t n, uint32_t seed,
                  const char *profile) {
    size_t i;
    int mode, ok = 1;
    FILE *f;
    if (!strcmp(profile, "random")) mode = 0;
    else if (!strcmp(profile, "sorted")) mode = 1;
    else if (!strcmp(profile, "reverse")) mode = 2;
    else if (!strcmp(profile, "duplicates")) mode = 3;
    else { fputs("Perfil invalido.\n", stderr); return 0; }
    if (!n || n > APS_MAX_N || !seed) return 0;
    f = fopen(path, "wx");
    if (!f) { perror(path); return 0; }
    for (i = 0; i < n; ++i) {
        uint32_t v;
        if (mode == 1) v = 100000u + (uint32_t)((uint64_t)i*900000u/n);
        else if (mode == 2)
            v = 100000u + (uint32_t)((uint64_t)(n-1-i)*900000u/n);
        else {
            uint32_t bound = mode == 3 ? 8u : 900000u;
            uint32_t x, limit = UINT32_MAX - UINT32_MAX % bound;
            do { x = rng_next(&seed); } while (x > limit);
            v = 100000u + (x-1u) % bound;
        }
        if (fprintf(f, "%lu\n", (unsigned long)v) < 0) { ok = 0; break; }
    }
    if (fclose(f) != 0) ok = 0;
    if (!ok) fputs("Falha ao gravar arquivo de dados.\n", stderr);
    return ok;
}
